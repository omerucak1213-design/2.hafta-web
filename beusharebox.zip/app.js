/**
 * BEUShareBox Pro - Professional Vanilla JS SPA
 * Features: Dark Mode, Image Upload, Sorting, Modal, Toasts, Stats, Import/Export
 */

// --- Constants ---
const STORAGE_KEY = 'beusharebox_pro_data';
const THEME_KEY = 'beusharebox_theme';

// --- State Management ---
const State = {
    products: [],
    theme: 'light',
    
    init() {
        this.loadProducts();
        this.loadTheme();
    },
    
    loadProducts() {
        const saved = localStorage.getItem(STORAGE_KEY);
        this.products = saved ? JSON.parse(saved) : [];
    },
    
    saveProducts() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.products));
    },
    
    loadTheme() {
        this.theme = localStorage.getItem(THEME_KEY) || 'light';
        document.body.className = this.theme + '-theme';
    },
    
    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem(THEME_KEY, this.theme);
        document.body.className = this.theme + '-theme';
        return this.theme;
    },
    
    addProduct(product) {
        this.products.unshift(product);
        this.saveProducts();
    },
    
    deleteProduct(id) {
        this.products = this.products.filter(p => p.id !== id);
        this.saveProducts();
    },
    
    updateProduct(id, updates) {
        const index = this.products.findIndex(p => p.id === id);
        if (index !== -1) {
            this.products[index] = { ...this.products[index], ...updates };
            this.saveProducts();
        }
    },
    
    getStats() {
        if (this.products.length === 0) return { total: 0, likes: 0, mostLiked: '-', topCategory: '-', avgPrice: '$0.00' };
        
        const totalLikes = this.products.reduce((sum, p) => sum + p.likes, 0);
        const mostLiked = [...this.products].sort((a, b) => b.likes - a.likes)[0];
        
        const categories = this.products.reduce((acc, p) => {
            acc[p.category] = (acc[p.category] || 0) + 1;
            return acc;
        }, {});
        const topCategory = Object.entries(categories).sort((a, b) => b[1] - a[1])[0][0];
        
        const avgPrice = this.products.reduce((sum, p) => sum + Number(p.price), 0) / this.products.length;
        
        return {
            total: this.products.length,
            likes: totalLikes,
            mostLiked: mostLiked.title,
            topCategory,
            avgPrice: `$${avgPrice.toFixed(2)}`
        };
    }
};

// --- UI Components ---
const UI = {
    renderProducts(products) {
        const container = document.getElementById('productList');
        container.innerHTML = '';
        
        if (products.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <p>No products found. Start by sharing something amazing!</p>
                </div>
            `;
            return;
        }
        
        products.forEach(product => {
            const card = document.createElement('article');
            card.className = 'product-card';
            card.dataset.id = product.id;
            
            const imageSrc = product.image || 'https://picsum.photos/seed/' + product.id + '/400/300';
            
            card.innerHTML = `
                <div class="card-image-container" onclick="App.openModal(${product.id})">
                    <img src="${imageSrc}" alt="${this.escapeHTML(product.title)}" class="card-image" loading="lazy">
                    <span class="card-badge">${product.category}</span>
                </div>
                <div class="card-content">
                    <span class="card-category">${product.category}</span>
                    <h3 class="card-title" onclick="App.openModal(${product.id})">${this.escapeHTML(product.title)}</h3>
                    <p class="card-price">$${Number(product.price).toFixed(2)}</p>
                    <p class="card-description">${this.escapeHTML(product.description)}</p>
                    ${product.url ? `<a href="${product.url}" target="_blank" class="btn-link" onclick="event.stopPropagation()">🔗 View Product</a>` : ''}
                </div>
                <div class="card-footer">
                    <div class="card-actions">
                        <button class="btn-card btn-like ${product.isLiked ? 'active' : ''}" data-action="like">
                            ${product.isLiked ? '❤️' : '🤍'} <span>${product.likes}</span>
                        </button>
                        <button class="btn-card btn-comment" onclick="App.openModal(${product.id})">
                            💬 <span>${product.comments.length}</span>
                        </button>
                    </div>
                    <button class="btn-card btn-delete-card" data-action="delete" title="Delete Product">
                        🗑️
                    </button>
                </div>
            `;
            container.appendChild(card);
        });
    },
    
    updateDashboard(stats) {
        document.getElementById('totalProductsCount').textContent = stats.total;
        document.getElementById('totalLikesCount').textContent = stats.likes;
        document.getElementById('mostLikedProduct').textContent = stats.mostLiked;
        document.getElementById('topCategory').textContent = stats.topCategory;
        document.getElementById('avgPrice').textContent = stats.avgPrice;
    },
    
    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `<span>${message}</span>`;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },
    
    renderModal(product) {
        const modalBody = document.getElementById('modalBody');
        const imageSrc = product.image || 'https://picsum.photos/seed/' + product.id + '/800/600';
        
        modalBody.innerHTML = `
            <div class="modal-body-content">
                <img src="${imageSrc}" alt="${this.escapeHTML(product.title)}" class="modal-image">
                <div class="modal-info">
                    <span class="card-category">${product.category}</span>
                    <h2 class="card-title">${this.escapeHTML(product.title)}</h2>
                    <p class="card-price">$${Number(product.price).toFixed(2)}</p>
                    <p class="card-description" style="-webkit-line-clamp: unset;">${this.escapeHTML(product.description)}</p>
                    ${product.url ? `<a href="${product.url}" target="_blank" class="btn-primary" style="display: inline-block; text-decoration: none; text-align: center; margin-bottom: 1rem;">🔗 Visit Website</a>` : ''}
                    <div class="card-actions" style="margin-top: 2rem;">
                        <button class="btn-primary" onclick="App.handleLike(${product.id})">
                            ${product.isLiked ? '❤️ Liked' : '🤍 Like'} (${product.likes})
                        </button>
                    </div>
                </div>
                <div class="modal-comments">
                    <h3>Comments (${product.comments.length})</h3>
                    <ul class="comment-list">
                        ${product.comments.length > 0 
                            ? product.comments.map(c => `<li class="comment-item">${this.escapeHTML(c)}</li>`).join('')
                            : '<li class="comment-item">No comments yet. Be the first!</li>'}
                    </ul>
                    <form class="comment-form" onsubmit="App.handleAddComment(event, ${product.id})">
                        <input type="text" placeholder="Write a comment..." required>
                        <button type="submit" class="btn-primary">Post</button>
                    </form>
                </div>
            </div>
        `;
    },
    
    escapeHTML(str) {
        const p = document.createElement('p');
        p.textContent = str;
        return p.innerHTML;
    }
};

// --- App Controller ---
const App = {
    init() {
        State.init();
        this.bindEvents();
        this.refreshUI();
    },
    
    bindEvents() {
        // Form Submission
        document.getElementById('productForm').addEventListener('submit', (e) => this.handleAddProduct(e));
        
        // Search & Filters
        document.getElementById('searchInput').addEventListener('input', () => this.handleFilters());
        document.getElementById('categoryFilter').addEventListener('change', () => this.handleFilters());
        document.getElementById('sortOption').addEventListener('change', () => this.handleFilters());
        
        // Theme Toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            State.toggleTheme();
            UI.showToast('Theme updated');
        });
        
        // Event Delegation for Product Cards
        document.getElementById('productList').addEventListener('click', (e) => {
            const card = e.target.closest('.product-card');
            if (!card) return;
            
            const id = parseInt(card.dataset.id);
            const action = e.target.closest('[data-action]')?.dataset.action;
            
            if (action === 'like') this.handleLike(id);
            if (action === 'delete') this.handleDelete(id);
        });
        
        // Modal Close
        document.querySelector('.close-modal').addEventListener('click', () => this.closeModal());
        window.addEventListener('click', (e) => {
            if (e.target === document.getElementById('productModal')) this.closeModal();
        });
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') this.closeModal();
        });
        
        // Export / Import
        document.getElementById('exportData').addEventListener('click', (e) => {
            e.preventDefault();
            this.handleExport();
        });
        
        document.getElementById('importDataBtn').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('importFile').click();
        });
        
        document.getElementById('importFile').addEventListener('change', (e) => this.handleImport(e));
        
        // File Input Label Update
        document.getElementById('productImage').addEventListener('change', (e) => {
            const fileName = e.target.files[0]?.name || 'Choose Image...';
            document.querySelector('.file-label').textContent = fileName;
        });
    },
    
    async handleAddProduct(e) {
        e.preventDefault();
        const form = e.target;
        const title = form.title.value.trim();
        const price = form.price.value;
        const category = form.category.value;
        const description = form.description.value.trim();
        const productUrl = form.productUrl.value.trim();
        const imageFile = form.productImage.files[0];
        
        let imageData = null;
        if (imageFile) {
            imageData = await this.fileToBase64(imageFile);
        }
        
        const newProduct = {
            id: Date.now(),
            title,
            price,
            category,
            description,
            url: productUrl,
            image: imageData,
            likes: 0,
            isLiked: false,
            comments: [],
            createdAt: new Date().toISOString()
        };
        
        State.addProduct(newProduct);
        form.reset();
        document.querySelector('.file-label').textContent = 'Choose Image...';
        
        this.refreshUI();
        UI.showToast('Product shared successfully!', 'success');
    },
    
    handleLike(id) {
        const product = State.products.find(p => p.id === id);
        if (product) {
            const isLiked = !product.isLiked;
            const likes = isLiked ? product.likes + 1 : product.likes - 1;
            State.updateProduct(id, { isLiked, likes });
            
            this.refreshUI();
            if (document.getElementById('productModal').style.display === 'block') {
                UI.renderModal(State.products.find(p => p.id === id));
            }
            
            UI.showToast(isLiked ? 'Product liked!' : 'Like removed');
        }
    },
    
    handleDelete(id) {
        if (confirm('Are you sure you want to delete this product?')) {
            State.deleteProduct(id);
            this.refreshUI();
            UI.showToast('Product deleted', 'danger');
        }
    },
    
    handleAddComment(e, id) {
        e.preventDefault();
        const input = e.target.querySelector('input');
        const text = input.value.trim();
        
        if (text) {
            const product = State.products.find(p => p.id === id);
            const comments = [...product.comments, text];
            State.updateProduct(id, { comments });
            
            input.value = '';
            UI.renderModal(State.products.find(p => p.id === id));
            this.refreshUI();
            UI.showToast('Comment posted');
        }
    },
    
    handleFilters() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const category = document.getElementById('categoryFilter').value;
        const sortBy = document.getElementById('sortOption').value;
        
        let filtered = State.products.filter(p => {
            const matchesSearch = p.title.toLowerCase().includes(searchTerm) || 
                                p.description.toLowerCase().includes(searchTerm);
            const matchesCategory = category === 'All' || p.category === category;
            return matchesSearch && matchesCategory;
        });
        
        // Sorting
        filtered.sort((a, b) => {
            if (sortBy === 'newest') return new Date(b.createdAt) - new Date(a.createdAt);
            if (sortBy === 'price-low') return a.price - b.price;
            if (sortBy === 'price-high') return b.price - a.price;
            if (sortBy === 'likes') return b.likes - a.likes;
            return 0;
        });
        
        UI.renderProducts(filtered);
    },
    
    openModal(id) {
        const product = State.products.find(p => p.id === id);
        if (product) {
            UI.renderModal(product);
            document.getElementById('productModal').style.display = 'block';
            document.body.style.overflow = 'hidden'; // Prevent scroll
        }
    },
    
    closeModal() {
        document.getElementById('productModal').style.display = 'none';
        document.body.style.overflow = 'auto';
    },
    
    handleExport() {
        const data = JSON.stringify(State.products, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `beusharebox_export_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        
        URL.revokeObjectURL(url);
        UI.showToast('Data exported successfully');
    },
    
    handleImport(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const imported = JSON.parse(event.target.result);
                if (Array.isArray(imported)) {
                    // Simple merge strategy: keep unique IDs, prefer imported
                    const existingIds = new Set(State.products.map(p => p.id));
                    const newItems = imported.filter(p => !existingIds.has(p.id));
                    
                    State.products = [...newItems, ...State.products];
                    State.saveProducts();
                    this.refreshUI();
                    UI.showToast(`Imported ${newItems.length} new products`, 'success');
                }
            } catch (err) {
                UI.showToast('Invalid JSON file', 'danger');
            }
        };
        reader.readAsText(file);
    },
    
    refreshUI() {
        this.handleFilters();
        UI.updateDashboard(State.getStats());
    },
    
    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }
};

// Start the Application
document.addEventListener('DOMContentLoaded', () => App.init());
